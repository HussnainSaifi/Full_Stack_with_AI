from fastapi import FastAPI
import pandas as pd
import joblib
from pydantic import BaseModel

app = FastAPI()
model = joblib.load(r"C:\Users\Hussnain Saifi\Desktop\House_prediction\model\house_prices_prediction.pkl")
class HouseData(BaseModel):
    area: float
    bedrooms: int
    age: int


@app.get("/")
def home():
    return {"message": "House Prediction API is running"}

@app.post("/predict")
def predict_prices(data: HouseData):

    new_house = pd.DataFrame(
        [[data.area, data.bedrooms, data.age]],
        columns=["Area" ,"Bedrooms" ,"Age"]
    )
    prediction = model.predict(new_house)
    return {"prediction price": prediction[0]
            }
