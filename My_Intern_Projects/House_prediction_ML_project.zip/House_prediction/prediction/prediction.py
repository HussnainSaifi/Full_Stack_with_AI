import joblib
import pandas as pd

model = joblib.load(r"C:\Users\Hussnain Saifi\Desktop\House_prediction\model\house_prices_prediction.pkl")
print("model successfull!")

new_house = pd.DataFrame(
    [[1500, 4, 15]],
    columns=["Area" ,"Bedrooms" ,"Age" ]
    )
prediction = model.predict(new_house)
print("Predicted House prices ", prediction)