import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np
import joblib

df = pd.read_csv(r"C:\Users\Hussnain Saifi\Desktop\House_prediction\dataset\house_price.csv")
# print(df.head())
# print(df.shape)
# print(df.isnull().sum())
# print(df.describe())
x = df[["Area", "Bedrooms", "Age"]]
y = df["Price"]
# print(x.head())
# print(y.head())
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
# print("Traing data ", x_train)
# print("testing data ", x_test)

model = LinearRegression()
model.fit(x_train, y_train)
print("model trained successfully")

prediction = model.predict(x_test)
print("Actual prices")
print(y_test.values)

print("predicted prices")
print(prediction)


mae = mean_absolute_error(y_test, prediction)
mse = mean_squared_error(y_test, prediction)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, prediction)

print("MAE ",mae)
print("MSE ", mse)
print("RMSE ", rmse)
print("R2 score ", r2)

joblib.dump(model, r"C:\Users\Hussnain Saifi\Desktop\House_prediction\model\house_prices_prediction.pkl")
print("model saved successfully")
