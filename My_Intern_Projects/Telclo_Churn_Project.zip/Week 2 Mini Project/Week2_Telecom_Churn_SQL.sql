USE telecom_db;

CREATE TABLE customer_info AS
SELECT
    CustomerID,
    City,
    Gender,
    SeniorCitizen,
    Partner,
    Dependents,
    TenureMonths
FROM telecom_churn;

CREATE TABLE service_usage AS
SELECT
    CustomerID,
    PhoneService,
    MultipleLines,
    InternetService,
    OnlineSecurity,
    OnlineBackup,
    DeviceProtection,
    TechSupport,
    StreamingTV,
    StreamingMovies,
    Contract,
    PaperlessBilling,
    PaymentMethod,
    MonthlyCharges,
    TotalCharges
FROM telecom_churn;

CREATE TABLE churn_status AS
SELECT
    CustomerID,
    SatisfactionScore,
    Churn,
    ChurnReason
FROM telecom_churn;

SELECT COUNT(*) AS Total_Customers
FROM customer_info;

SELECT COUNT(*) AS Churned_Customers
FROM churn_status
WHERE Churn='Yes';

SELECT
ROUND(
(COUNT(CASE WHEN Churn='Yes' THEN 1 END) * 100.0) / COUNT(*),
2
) AS Churn_Percentage
FROM churn_status;

SELECT
ChurnReason,
COUNT(*) AS Total
FROM churn_status
WHERE Churn='Yes'
GROUP BY ChurnReason
ORDER BY Total DESC
LIMIT 3;