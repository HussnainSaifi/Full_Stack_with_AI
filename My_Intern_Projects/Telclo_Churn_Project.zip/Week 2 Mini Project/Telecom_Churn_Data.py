import pandas as pd
df = pd.read_csv(r"D:\Intership Program\Week 2 Mini Project\telecom churn dataset.csv")

print("First Five Lines From dataset")
print(df.head())

print("Info of Dataset")
print(df.info())

print("Checking Duplicates and drop them")
print(df.duplicated().sum())
df = df.drop_duplicates()
print("After Droping duplicate are = ",df.duplicated().sum())

print("Missing Values")
print(df.isnull().sum())
df["TotalCharges"] = df["TotalCharges"].fillna(df["TotalCharges"].median())
df["ChurnReason"] = df["ChurnReason"].fillna("Not Churn")

print("Is missing value handle checking")
print(df.isnull().sum())

# Creating Cleaned CSV
df.to_csv(r"D:/Intership Program/Week 2 Mini Project/Cleaned_telecom_churn_Data.csv", index=False)
print("File Created Sucessfully")