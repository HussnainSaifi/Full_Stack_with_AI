# ==========================================================
# Credit Card Default - Data Engineering Pipeline
# Phase 1 : Data Discovery & Profiling
# ==========================================================

import os
import glob
import pandas as pd

# ----------------------------------------------------------
# Project Paths
# ----------------------------------------------------------

RAW_DATA_FOLDER = "raw_data"
DOCS_FOLDER = "docs"

os.makedirs(DOCS_FOLDER, exist_ok=True)

# ----------------------------------------------------------
# Find All CSV Files
# ----------------------------------------------------------

csv_files = glob.glob(os.path.join(RAW_DATA_FOLDER, "*.csv"))

print("=" * 60)
print("Credit Card Default Data Preparation Pipeline")
print("=" * 60)

print(f"\nCSV Files Found : {len(csv_files)}\n")

if len(csv_files) == 0:
    raise FileNotFoundError("No CSV files found inside raw_data folder.")

# ----------------------------------------------------------
# Create Profiling Report
# ----------------------------------------------------------

report = []

report.append("# Data Discovery & Profiling Report\n")

# ----------------------------------------------------------
# Read Every File
# ----------------------------------------------------------

for file in sorted(csv_files):

    filename = os.path.basename(file)

    print("-" * 60)
    print(f"Loading : {filename}")

    try:

        df = pd.read_csv(file)

        rows, cols = df.shape

        print(f"Rows    : {rows}")
        print(f"Columns : {cols}")

        report.append(f"## {filename}")
        report.append(f"- Rows : {rows}")
        report.append(f"- Columns : {cols}")

        report.append("\n### Column Information\n")

        for column in df.columns:

            dtype = str(df[column].dtype)
            missing = int(df[column].isnull().sum())

            report.append(
                f"- {column} | Type = {dtype} | Missing = {missing}"
            )

        report.append("\n")

    except Exception as e:

        print(f"Error : {e}")

        report.append(f"## {filename}")
        report.append(f"Error Loading File : {e}\n")

# ----------------------------------------------------------
# Save Report
# ----------------------------------------------------------

report_path = os.path.join(DOCS_FOLDER, "profiling_report.md")

with open(report_path, "w", encoding="utf-8") as f:
    f.write("\n".join(report))

print("\nProfiling Report Saved Successfully.")
print(report_path)

print("\nPhase 1 Completed Successfully.")


# ==========================================================
# Phase 2 : Schema Discovery
# ==========================================================

print("\n" + "=" * 60)
print("Phase 2 : Schema Discovery")
print("=" * 60)

schema_summary = []
all_columns = set()

for file in sorted(csv_files):

    filename = os.path.basename(file)

    print(f"\nProcessing : {filename}")

    df = pd.read_csv(file)

    schema_summary.append(f"\n{'='*70}")
    schema_summary.append(f"FILE : {filename}")
    schema_summary.append(f"{'='*70}")

    schema_summary.append(f"\nRows : {df.shape[0]}")
    schema_summary.append(f"Columns : {df.shape[1]}\n")

    schema_summary.append("COLUMN DETAILS\n")

    for column in df.columns:

        dtype = str(df[column].dtype)

        missing = df[column].isnull().sum()

        unique = df[column].nunique(dropna=True)

        schema_summary.append(
            f"{column} | Type={dtype} | Missing={missing} | Unique={unique}"
        )

        all_columns.add(column)

schema_path = os.path.join(DOCS_FOLDER, "schema_discovery.md")

with open(schema_path, "w", encoding="utf-8") as f:

    f.write("\n".join(schema_summary))

print("\nSchema Discovery Saved.")

print(f"Unique Columns Found : {len(all_columns)}")

print("\nAll Unique Columns\n")

for column in sorted(all_columns):

    print(column)


    # ==========================================================
# Phase 3 : Canonical Schema & Column Mapping
# ==========================================================

print("\n" + "=" * 60)
print("Phase 3 : Canonical Schema")
print("=" * 60)

MAPPING_FOLDER = "mapping"
os.makedirs(MAPPING_FOLDER, exist_ok=True)

# ----------------------------------------------------------
# Canonical Schema
# ----------------------------------------------------------

canonical_schema = [

    ("customer_id","Unique Customer Identifier"),
    ("credit_limit","Customer Credit Limit"),
    ("gender","Customer Gender"),
    ("age","Customer Age"),
    ("education","Education Level"),
    ("marital_status","Marital Status"),

    ("repay_status_m1","Repayment Status Month 1"),
    ("repay_status_m2","Repayment Status Month 2"),
    ("repay_status_m3","Repayment Status Month 3"),
    ("repay_status_m4","Repayment Status Month 4"),
    ("repay_status_m5","Repayment Status Month 5"),
    ("repay_status_m6","Repayment Status Month 6"),

    ("bill_amt_m1","Bill Amount Month 1"),
    ("bill_amt_m2","Bill Amount Month 2"),
    ("bill_amt_m3","Bill Amount Month 3"),
    ("bill_amt_m4","Bill Amount Month 4"),
    ("bill_amt_m5","Bill Amount Month 5"),
    ("bill_amt_m6","Bill Amount Month 6"),

    ("pay_amt_m1","Payment Amount Month 1"),
    ("pay_amt_m2","Payment Amount Month 2"),
    ("pay_amt_m3","Payment Amount Month 3"),
    ("pay_amt_m4","Payment Amount Month 4"),
    ("pay_amt_m5","Payment Amount Month 5"),
    ("pay_amt_m6","Payment Amount Month 6"),

    ("default_next_month","Target")
]

schema_df = pd.DataFrame(
    canonical_schema,
    columns=["canonical_column","description"]
)

schema_df.to_csv(
    os.path.join(MAPPING_FOLDER,"canonical_schema.csv"),
    index=False
)

# ----------------------------------------------------------
# Source Column Mapping
# ----------------------------------------------------------

mapping = {

"customer_id":[
"ID",
"CLIENT_ID",
"customerId",
"cust_no",
"account_holder_id"
],

"credit_limit":[
"LIMIT_BAL",
"creditLimit",
"credit_limit",
"approved_limit",
"credit_limit_amt"
],

"gender":[
"SEX",
"gender",
"Gender_Code",
"customer_gender",
"sex_code"
],

"age":[
"AGE",
"AgeYears",
"customerAge",
"customer_age",
"age_in_years"
],

"education":[
"EDUCATION",
"education_level",
"education_code",
"eduLevel",
"qualification"
],

"marital_status":[
"MARRIAGE",
"marital",
"marital_status",
"marriageStatus",
"civil_status"
],

"default_next_month":[
"DEFAULT",
"target",
"isDefault",
"next_month_default",
"default_payment_next_month"
]

}

# Repayment Status

for i in range(1,7):

    mapping[f"repay_status_m{i}"]=[
        f"PAY_{0 if i==1 else i}",
        f"repay_{i}",
        f"repaymentStatusM{i}",
        f"repayment_status_m{i}",
        f"status_month_{i}"
    ]

# Bill Amount

for i in range(1,7):

    mapping[f"bill_amt_m{i}"]=[
        f"BILL_AMT{i}",
        f"bill_{i}",
        f"billAmountM{i}",
        f"bill_amount_m{i}",
        f"statement_balance_{i}"
    ]

# Payment Amount

for i in range(1,7):

    mapping[f"pay_amt_m{i}"]=[
        f"PAY_AMT{i}",
        f"payment_{i}",
        f"paymentAmountM{i}",
        f"payment_amount_m{i}",
        f"paid_amount_{i}"
    ]

rows=[]

for canonical,source_list in mapping.items():

    for source in source_list:

        rows.append([source,canonical])

mapping_df=pd.DataFrame(
    rows,
    columns=["source_column","canonical_column"]
)

mapping_df.to_csv(
    os.path.join(MAPPING_FOLDER,"column_mapping.csv"),
    index=False
)

print("\nCanonical Schema Saved.")
print("Column Mapping Saved.")

print("\nPhase 3 Completed Successfully.")

# ==========================================================
# Phase 4 : Standardization & Consolidation
# ==========================================================

print("\n" + "=" * 60)
print("Phase 4 : Standardization & Consolidation")
print("=" * 60)

OUTPUT_FOLDER = "output"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Read Mapping File
mapping_df = pd.read_csv(os.path.join(MAPPING_FOLDER, "column_mapping.csv"))

# Create Dictionary
mapping_dict = {}

for canonical in mapping_df["canonical_column"].unique():

    mapping_dict[canonical] = mapping_df[
        mapping_df["canonical_column"] == canonical
    ]["source_column"].tolist()

# Canonical Column Order
canonical_columns = schema_df["canonical_column"].tolist()

all_data = []

# ----------------------------------------------------------
# Process Every CSV File
# ----------------------------------------------------------

for file in sorted(csv_files):

    filename = os.path.basename(file)

    print(f"\nStandardizing : {filename}")

    df = pd.read_csv(file, dtype=str)

    standardized = pd.DataFrame()

    # ----------------------------------------
    # Rename Equivalent Columns
    # ----------------------------------------

    for canonical in canonical_columns:

        found = False

        for source in mapping_dict.get(canonical, []):

            if source in df.columns:

                standardized[canonical] = df[source]

                found = True

                break

        if not found:

            standardized[canonical] = pd.NA

    # ----------------------------------------
    # Add Provenance Columns
    # ----------------------------------------

    standardized["source_file"] = filename

    standardized["source_row"] = range(1, len(df) + 1)

    all_data.append(standardized)

print("\nAll Files Standardized Successfully.")

# ----------------------------------------------------------
# Combine All Standardized Files
# ----------------------------------------------------------

standardized_dataset = pd.concat(
    all_data,
    ignore_index=True
)

print("\nCombining All Standardized Files...")

print(f"Total Rows    : {standardized_dataset.shape[0]}")
print(f"Total Columns : {standardized_dataset.shape[1]}")

# ----------------------------------------------------------
# Arrange Columns
# ----------------------------------------------------------

final_columns = canonical_columns + [
    "source_file",
    "source_row"
]

standardized_dataset = standardized_dataset[final_columns]

# ----------------------------------------------------------
# Save Standardized Dataset
# ----------------------------------------------------------

standardized_path = os.path.join(
    OUTPUT_FOLDER,
    "standardized_dataset.csv"
)

standardized_dataset.to_csv(
    standardized_path,
    index=False
)

print("\nStandardized Dataset Saved Successfully.")

print(standardized_path)

print("\nDataset Preview\n")

print(standardized_dataset.head())

print("\nPhase 4 Completed Successfully.")

# ==========================================================
# Phase 5 : Data Cleaning
# ==========================================================

print("\n" + "=" * 60)
print("Phase 5 : Data Cleaning")
print("=" * 60)

cleaned_dataset = standardized_dataset.copy()

# ----------------------------------------------------------
# Missing Value Standardization
# ----------------------------------------------------------

missing_values = [
    "",
    " ",
    "NULL",
    "Null",
    "null",
    "N/A",
    "n/a",
    "NA",
    "na",
    "?",
    "None",
    "none",
    "Unknown",
    "unknown",
    "missing",
    "Missing"
]

cleaned_dataset.replace(missing_values, pd.NA, inplace=True)

print("✓ Missing values standardized.")


# ----------------------------------------------------------
# Numeric Column Cleaning
# ----------------------------------------------------------

numeric_columns = [

    "credit_limit",

    "bill_amt_m1","bill_amt_m2","bill_amt_m3",
    "bill_amt_m4","bill_amt_m5","bill_amt_m6",

    "pay_amt_m1","pay_amt_m2","pay_amt_m3",
    "pay_amt_m4","pay_amt_m5","pay_amt_m6",

    "age"

]

for col in numeric_columns:

    if col in cleaned_dataset.columns:

        cleaned_dataset[col] = (

            cleaned_dataset[col]
            .astype(str)
            .str.replace("PKR","",regex=False)
            .str.replace(",","",regex=False)
            .str.replace("years","",regex=False)
            .str.replace("Years","",regex=False)
            .str.replace("YEAR","",regex=False)
            .str.replace("YEARS","",regex=False)
            .str.strip()

        )

        cleaned_dataset[col] = pd.to_numeric(
            cleaned_dataset[col],
            errors="coerce"
        )

print("✓ Numeric columns cleaned.")

# ----------------------------------------------------------
# Gender Standardization
# ----------------------------------------------------------
# ----------------------------------------------------------
# Extra Gender Cleaning
# ----------------------------------------------------------

cleaned_dataset["gender"] = (
    cleaned_dataset["gender"]
    .astype(str)
    .str.strip()
    .str.upper()
)

gender_fix = {
    "M": "Male",
    "MALE": "Male",
    "1": "Male",

    "F": "Female",
    "FEMALE": "Female",
    "2": "Female"
}

cleaned_dataset["gender"] = cleaned_dataset["gender"].replace(gender_fix)

invalid_gender_values = [
    "SEX",
    "GENDER",
    "GENDER_CODE",
    "CUSTOMER_GENDER",
    "X",
    "-999",
    "UNKNOWN",
    "N/A"
]

cleaned_dataset.loc[
    cleaned_dataset["gender"].isin(invalid_gender_values),
    "gender"
] = pd.NA

print("✓ Gender standardized.")

# ----------------------------------------------------------
# Target Standardization
# ----------------------------------------------------------

cleaned_dataset["default_next_month"] = (
    cleaned_dataset["default_next_month"]
    .astype(str)
    .str.strip()
    .str.upper()
)

target_fix = {
    "TRUE": 1,
    "FALSE": 0,
    "YES": 1,
    "NO": 0,
    "Y": 1,
    "N": 0,
    "1": 1,
    "0": 0
}

cleaned_dataset["default_next_month"] = (
    cleaned_dataset["default_next_month"]
    .replace(target_fix)
)

invalid_target = [
    "TARGET",
    "DEFAULT",
    "ISDEFAULT",
    "NEXT_MONTH_DEFAULT",
    "DEFAULT_PAYMENT_NEXT_MONTH"
]

cleaned_dataset.loc[
    cleaned_dataset["default_next_month"].isin(invalid_target),
    "default_next_month"
] = pd.NA

print("✓ Target standardized.")

# ----------------------------------------------------------
# Duplicate Detection
# ----------------------------------------------------------

duplicate_count = cleaned_dataset.duplicated().sum()

print(f"Duplicate Records : {duplicate_count}")

cleaned_dataset = cleaned_dataset.drop_duplicates()

print(f"Rows After Removing Duplicates : {len(cleaned_dataset)}")
# ----------------------------------------------------------
# Save Cleaned Dataset
# ----------------------------------------------------------

cleaned_path = os.path.join(

    OUTPUT_FOLDER,

    "cleaned_dataset.csv"

)

cleaned_dataset.to_csv(

    cleaned_path,

    index=False

)

print("\nCleaned Dataset Saved Successfully.")

print(cleaned_path)

print("\nPhase 5 Completed Successfully.")
# ==========================================================
# Phase 6 : Feature Engineering
# ==========================================================

print("\n" + "=" * 60)
print("Phase 6 : Feature Engineering")
print("=" * 60)

feature_dataset = cleaned_dataset.copy()

# ----------------------------------------------------------
# Total Bill Amount
# ----------------------------------------------------------

bill_columns = [

    "bill_amt_m1",
    "bill_amt_m2",
    "bill_amt_m3",
    "bill_amt_m4",
    "bill_amt_m5",
    "bill_amt_m6"

]

feature_dataset["total_bill"] = feature_dataset[bill_columns].sum(axis=1)

# ----------------------------------------------------------
# Average Bill
# ----------------------------------------------------------

feature_dataset["average_bill"] = feature_dataset[bill_columns].mean(axis=1)

# ----------------------------------------------------------
# Total Payment
# ----------------------------------------------------------

payment_columns = [

    "pay_amt_m1",
    "pay_amt_m2",
    "pay_amt_m3",
    "pay_amt_m4",
    "pay_amt_m5",
    "pay_amt_m6"

]

feature_dataset["total_payment"] = feature_dataset[payment_columns].sum(axis=1)

# ----------------------------------------------------------
# Average Payment
# ----------------------------------------------------------

feature_dataset["average_payment"] = feature_dataset[payment_columns].mean(axis=1)

# ----------------------------------------------------------
# Credit Utilization
# ----------------------------------------------------------

feature_dataset["credit_utilization"] = (

    feature_dataset["total_bill"] /

    feature_dataset["credit_limit"]

)

feature_dataset["credit_utilization"] = (

    feature_dataset["credit_utilization"]

    .replace([float("inf"), -float("inf")], pd.NA)

)

# ----------------------------------------------------------
# Payment Ratio
# ----------------------------------------------------------

feature_dataset["payment_ratio"] = (

    feature_dataset["total_payment"] /

    feature_dataset["total_bill"]

)

feature_dataset["payment_ratio"] = (

    feature_dataset["payment_ratio"]

    .replace([float("inf"), -float("inf")], pd.NA)

)

# ----------------------------------------------------------
# Average Repayment Status
# ----------------------------------------------------------

repay_columns = [

    "repay_status_m1",
    "repay_status_m2",
    "repay_status_m3",
    "repay_status_m4",
    "repay_status_m5",
    "repay_status_m6"

]

for col in repay_columns:

    feature_dataset[col] = pd.to_numeric(

        feature_dataset[col],

        errors="coerce"

    )

feature_dataset["avg_repayment_status"] = (

    feature_dataset[repay_columns]

    .mean(axis=1)

)

print("✓ Features Created Successfully.")
# ----------------------------------------------------------
# Save Model Ready Dataset
# ----------------------------------------------------------

feature_path = os.path.join(

    OUTPUT_FOLDER,

    "model_ready_dataset.csv"

)

feature_dataset.to_csv(

    feature_path,

    index=False

)

print("\nModel Ready Dataset Saved Successfully.")

print(feature_path)

print("\nTotal Features :", feature_dataset.shape[1])

print("\nPhase 6 Completed Successfully.")
# ==========================================================
# Phase 7 : Validation
# ==========================================================

print("\n" + "=" * 60)
print("Phase 7 : Validation")
print("=" * 60)

validation_results = []

# ----------------------------------------------------------
# Total Records
# ----------------------------------------------------------

validation_results.append([
    "Total Records",
    len(feature_dataset),
    "PASS"
])

# ----------------------------------------------------------
# Duplicate Records
# ----------------------------------------------------------

duplicate_count = feature_dataset.duplicated().sum()

status = "PASS"

if duplicate_count > 0:
    status = "FAIL"

validation_results.append([
    "Duplicate Records",
    duplicate_count,
    status
])

# ----------------------------------------------------------
# Missing Values
# ----------------------------------------------------------

missing_total = feature_dataset.isnull().sum().sum()

status = "PASS"

if missing_total > 0:
    status = "WARNING"

validation_results.append([
    "Missing Values",
    missing_total,
    status
])

# ----------------------------------------------------------
# Invalid Age
# ----------------------------------------------------------

invalid_age = feature_dataset[
    (feature_dataset["age"] < 18) |
    (feature_dataset["age"] > 100)
]

status = "PASS"

if len(invalid_age) > 0:
    status = "WARNING"

validation_results.append([
    "Invalid Age",
    len(invalid_age),
    status
])

# ----------------------------------------------------------
# Invalid Credit Limit
# ----------------------------------------------------------

invalid_credit = feature_dataset[
    feature_dataset["credit_limit"] <= 0
]

status = "PASS"

if len(invalid_credit) > 0:
    status = "WARNING"

validation_results.append([
    "Invalid Credit Limit",
    len(invalid_credit),
    status
])

# ----------------------------------------------------------
# Invalid Gender
# ----------------------------------------------------------

valid_gender = ["Male", "Female"]

invalid_gender = feature_dataset[
    ~feature_dataset["gender"].isin(valid_gender)
]

status = "PASS"

if len(invalid_gender) > 0:
    status = "WARNING"

validation_results.append([
    "Invalid Gender",
    len(invalid_gender),
    status
])

# ----------------------------------------------------------
# Invalid Target
# ----------------------------------------------------------

valid_target = [0, 1]

invalid_target = feature_dataset[
    ~feature_dataset["default_next_month"].isin(valid_target)
]

status = "PASS"

if len(invalid_target) > 0:
    status = "WARNING"

validation_results.append([
    "Invalid Target",
    len(invalid_target),
    status
])

# ----------------------------------------------------------
# Save Validation Report
# ----------------------------------------------------------

validation_df = pd.DataFrame(

    validation_results,

    columns=[
        "Validation Check",
        "Count",
        "Status"
    ]

)

validation_path = os.path.join(

    OUTPUT_FOLDER,

    "validation_report.csv"

)

validation_df.to_csv(

    validation_path,

    index=False

)

print(validation_df)

print("\nValidation Report Saved Successfully.")

print(validation_path)

print("\nPhase 7 Completed Successfully.")
# ==========================================================
# Phase 8 : Rejected Records
# ==========================================================

print("\n" + "=" * 60)
print("Phase 8 : Rejected Records")
print("=" * 60)

rejected_records = feature_dataset[

    (feature_dataset["gender"].isna()) |

    (feature_dataset["default_next_month"].isna()) |

    (feature_dataset["age"] < 18) |

    (feature_dataset["age"] > 100) |

    (feature_dataset["credit_limit"] <= 0)

].copy()

rejected_path = os.path.join(

    OUTPUT_FOLDER,

    "rejected_records.csv"

)

rejected_records.to_csv(

    rejected_path,

    index=False

)

print(f"Rejected Records : {len(rejected_records)}")

print("Rejected Records File Saved.")
# ==========================================================
# Row Reconciliation
# ==========================================================

reconciliation = pd.DataFrame({

    "Stage":[

        "Raw Dataset",

        "After Standardization",

        "After Cleaning",

        "Rejected Records",

        "Model Ready"

    ],

    "Rows":[

        30880,

        len(standardized_dataset),

        len(cleaned_dataset),

        len(rejected_records),

        len(feature_dataset)-len(rejected_records)

    ]

})

reconciliation_path = os.path.join(

    OUTPUT_FOLDER,

    "row_reconciliation.csv"

)

reconciliation.to_csv(

    reconciliation_path,

    index=False

)

print("Row Reconciliation Saved.")

print(reconciliation)

print("\nPhase 8 Completed Successfully.")