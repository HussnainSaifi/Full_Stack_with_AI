# Credit Card Data Engineering Assignment

## Project Overview

This project combines multiple credit card customer datasets into a single standardized dataset. The pipeline performs schema mapping, data standardization, data cleaning, feature engineering, validation, and generates a model-ready dataset.

---

## Project Structure

```
CreditCard_Assignment/
│
├── raw_data/
├── output/
├── mapping/
├── docs/
│
├── pipeline.py
├── requirements.txt
└── README.md
```

---

## Technologies Used

* Python
* Pandas
* NumPy

---

## Pipeline Steps

1. Data Discovery
2. Schema Discovery
3. Canonical Schema Creation
4. Column Mapping
5. Data Standardization
6. Data Cleaning
7. Feature Engineering
8. Validation
9. Rejected Record Generation
10. Row Reconciliation

---

## Output Files

* canonical_schema.csv
* column_mapping.csv
* standardized_dataset.csv
* cleaned_dataset.csv
* model_ready_dataset.csv
* validation_report.csv
* rejected_records.csv
* row_reconciliation.csv

---

## How to Run

Install the required libraries.

```
pip install -r requirements.txt
```

Run the pipeline.

```
python pipeline.py
```

All output files will be generated automatically inside the output folder.
