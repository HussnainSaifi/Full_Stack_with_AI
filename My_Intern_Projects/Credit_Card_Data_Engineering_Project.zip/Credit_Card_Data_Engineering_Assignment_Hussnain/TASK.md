# Credit-Card Default Data Preparation and Feature Engineering Task

## 1. Task Overview

Real-world machine-learning data rarely arrives as one clean, consistently formatted table. It is often distributed across multiple exports produced by different systems, teams, or reporting processes. These sources may represent the same information using different column names, column orders, data types, category labels, formats, and quality conventions.

You have been provided with ten CSV files containing credit-card customer and payment-history data. Your task is to design and implement a reproducible data-preparation and feature-engineering pipeline that converts these raw files into one reliable, model-ready dataset.

The purpose of this assignment is not simply to produce a cleaned CSV. The goal is to demonstrate how an AI or machine-learning engineer investigates unfamiliar data, defines a consistent data contract, handles real-world quality problems, makes defensible cleaning decisions, engineers useful features, and validates the resulting dataset.

## 2. Business Scenario and Real-World Use

You are working as an AI engineer for a financial-services company that provides revolving credit facilities to customers. The company receives customer and account information from several operational systems, regional teams, and historical exports. Because these systems were developed at different times, their data structures and quality conventions are inconsistent.

The credit-risk team wants to develop an early-warning system that estimates whether an existing customer is likely to default on their payment in the following month. The intended prediction is made at the end of the current reporting period using only information that would be available at that time.

The future model may help authorized credit-risk and customer-support teams:

- Identify accounts that may require closer review.
- Prioritize voluntary payment reminders or customer outreach.
- Offer suitable payment-plan or financial-support options.
- Monitor changes in portfolio-level default risk.
- Support risk analysts when reviewing credit policies.
- Allocate limited collections and support resources more effectively.

The model output is intended to be a **risk indicator that supports human review**. It must not be presented as proof that a customer will default, and it should not be used as the sole basis for automatically denying services, applying penalties, or taking adverse action against a customer.

Your assignment covers the data foundation required for this future system. A model trained on incorrectly combined, duplicated, malformed, or leakage-prone data could produce misleading risk estimates and lead to poor customer or business decisions. For that reason, schema design, data lineage, cleaning decisions, validation, and feature definitions are treated as engineering requirements rather than optional preparation.

### Business users

Potential users of the future model output include:

- Credit-risk analysts.
- Portfolio-risk managers.
- Customer-support and payment-assistance teams.
- Collections planning teams.
- Model-risk and compliance reviewers.

### Unit of analysis

The intended unit of analysis is one customer account at one prediction point. The final modeling table should therefore represent each customer consistently and avoid duplicate entities that could bias training or evaluation.

### Prediction objective

For each customer, use historical and current-period information to estimate the likelihood of default in the next month. Features must be based only on information available before the outcome occurs.

### Business consequences of poor data preparation

Examples include:

- Duplicate customers receiving excessive weight during model training.
- Incorrect monetary parsing producing unrealistic utilization features.
- Conflicting account records assigning the wrong behaviour to a customer.
- Missing-value handling hiding important data-collection failures.
- Target leakage producing impressive evaluation results that fail in production.
- Identifier or source-system fields causing the model to learn system artifacts instead of customer behaviour.
- Unexplained demographic treatment creating fairness, compliance, or reputational concerns.

Your report should connect important data-quality and feature-engineering decisions to these operational risks.

## 3. Machine-Learning Problem

The dataset describes customer demographics, credit limits, repayment behaviour, monthly bill amounts, monthly payment amounts, and whether a customer defaults in the following month.

This is a **supervised binary classification problem**. The target represents one of two possible outcomes: default or no default in the next month.

Your work in this assignment should focus on data understanding, standardization, cleaning, and feature engineering. Training a final machine-learning model is outside the required scope unless separately requested.

## 4. Primary Objective

Build a reproducible pipeline that:

1. Discovers and profiles all provided source files.
2. Defines a single canonical schema for the combined dataset.
3. Standardizes and consolidates all source records.
4. Detects data-quality problems that could make the data unreliable or unsuitable for model training.
5. Cleans the data using justified and documented rules.
6. Engineers meaningful features that could help predict next-month default.
7. Validates that the final dataset is internally consistent and ready for downstream modeling.

Your pipeline must be repeatable from the original raw files. Manual editing of CSV files is not permitted.

## 5. Technical and Automation Requirements

This is a **Python-based data engineering assignment**. All material data discovery, schema standardization, consolidation, cleaning, feature engineering, and validation must be implemented programmatically in Python.

You may use appropriate Python libraries such as pandas, NumPy, scikit-learn, or data-validation libraries. You may also use Jupyter Notebook for exploration and presentation. However, the complete workflow must remain reproducible from the untouched raw files.

### Manual inspection that is allowed

You may manually open or preview files to understand their structure, inspect examples, verify assumptions, and review generated outputs. You may use a spreadsheet application as a read-only aid during investigation.

### Manual data editing that is not allowed

You must not:

- Open the raw CSV files and correct individual cells by hand.
- Delete problematic rows manually.
- Rearrange or rename source columns manually before loading them.
- Copy and paste records between files.
- Create the final cleaned dataset using spreadsheet-only operations.
- Hardcode lists of row numbers simply to remove known problematic records.
- Make undocumented changes outside the Python pipeline.

Cleaning rules must be based on identifiable conditions and implemented in code. For example, the pipeline should detect a class of invalid values and apply a documented rule rather than correcting individual rows one by one.

### Reproducibility requirement

Another engineer should be able to place the original ten CSV files in the expected input directory, run one documented Python command, and regenerate the standardized, cleaned, validated, and feature-engineered outputs without manually changing the source files or executing notebook cells in a special order.

The pipeline should fail clearly or report meaningful warnings when expected files, required columns, mappings, or validation conditions are missing.

## 6. Provided Material

The `raw_data/` directory contains ten CSV files. Treat these files as independent source exports rather than assuming that any one file defines the correct schema or format.

The files may differ in areas such as:

- Column names.
- Column order.
- Number of columns.
- Data representations and inferred data types.
- Category labels and codes.
- Identifier formatting.
- Numeric and monetary formatting.
- Presence of operational or export-related columns.
- Data quality and completeness.
- Repeated, overlapping, or conflicting records.

This list is directional rather than exhaustive. You are expected to profile the data and identify issues independently.

## 7. Required Work

### Phase 1: Data discovery and profiling

Begin by inspecting every file independently before attempting to combine them.

Your profiling should establish, at minimum:

- Which files were discovered and loaded.
- Row and column counts for each file.
- Column names and likely meanings.
- Inferred data types and formatting differences.
- Candidate identifier, target, feature, and metadata columns.
- Missing-value representations.
- Category values and their variations.
- Numeric ranges and suspicious values.
- Potential duplicate or overlapping records.
- Differences between source schemas.

Do not begin by forcing all files into one table without first understanding how their schemas relate.

### Phase 2: Define a canonical schema

Design a **canonical schema**, meaning one authoritative structure that all source records will follow after standardization.

The schema should specify:

- Canonical column names.
- Exact column order.
- Intended data type of every column.
- Meaning of every field.
- Required and optional fields.
- Allowed category values or codes.
- Fields that should be retained.
- Fields that should be used only for provenance or conflict resolution.
- Fields that should be discarded from the final modeling table.
- The identifier and target columns.

Create an explicit source-to-canonical mapping rather than scattering column-renaming decisions throughout the code.

You are responsible for deciding what the standard should be. Your choices must be consistent, reasonable, and documented.

### Phase 3: Standardize and consolidate the files

Transform every source file into the canonical format, then combine the standardized records into one dataset.

The standardization process should consider:

- Equivalent columns with different names.
- Different column ordering.
- Columns absent from particular files.
- Inconsistent identifier formats.
- Numeric fields stored as formatted text.
- Inconsistent category representations.
- Different binary-target representations.
- Operational or export columns that are not appropriate model features.

Retain record provenance during processing. You should be able to determine which source file and source row produced any standardized record. Provenance may be needed to understand conflicts, but it should not automatically become a predictive feature.

Save the standardized combined dataset before applying final cleaning so the stages remain auditable.

### Phase 4: Data-quality assessment

Investigate the consolidated data for problems that could reduce model reliability, distort engineered features, cause processing failures, or introduce incorrect assumptions.

Consider areas such as:

- Missing or incomplete values.
- Multiple representations of missing data.
- Exact and near-duplicate records.
- The same customer appearing in multiple sources.
- Conflicting versions of a customer record.
- Invalid identifiers.
- Invalid or inconsistent categories.
- Numeric parsing failures.
- Impossible or suspicious ranges.
- Extreme values and potential outliers.
- Formatting and whitespace issues.
- Rows that may not represent actual customer records.
- Class balance of the target.
- Potential sources of target leakage.

Do not assume that every unusual value is incorrect. Some fields may legitimately contain zero, negative, or extreme values. Cleaning decisions should consider the meaning of the field and evidence available in the data.

### Phase 5: Data cleaning

Create documented and reproducible rules for resolving the identified issues.

Your approach should explain:

- How missing-value representations were normalized.
- How missing values were handled for different field types.
- How duplicate and overlapping records were identified.
- How conflicting customer records were resolved or flagged.
- How categories were standardized.
- How invalid numeric values were treated.
- How plausible outliers were distinguished from likely errors.
- Which rows or fields were rejected, and why.
- Which issues could not be resolved confidently.

Do not silently remove records or replace questionable values without recording the decision. If available evidence is insufficient, treating a value as missing or flagging it for review may be more appropriate than guessing.

Save the cleaned dataset as a separate output. The cleaned table should represent one consistent customer-level dataset suitable for feature engineering.

### Phase 6: Feature engineering

Create features that summarize customer credit usage, repayment behaviour, payment history, and changes over time in ways that may help predict next-month default.

Your feature choices should be driven by the available data and a reasonable hypothesis about default risk. Possible areas of investigation include:

- Credit utilization.
- Repayment delays and repayment consistency.
- Payment behaviour.
- Bill and payment trends.
- Volatility or stability over time.
- Recent behaviour compared with longer-term behaviour.
- Relationships between payment amounts, bill amounts, and credit limits.

This list provides direction, not a required feature solution. You should determine the final feature set yourself.

For every engineered feature, document:

- Feature name.
- Definition or formula.
- Source columns.
- Expected relationship to default risk.
- Handling of missing inputs.
- Handling of zero or invalid denominators.
- Any transformation, capping, encoding, or scaling applied.
- Why the feature does not introduce target leakage.

Customer identifiers, source filenames, row numbers, export metadata, and the target itself must not be used as predictive features without a defensible deployment-based justification.

### Phase 7: Validation

Build automated checks that demonstrate that the final dataset satisfies your stated schema and cleaning rules.

Validation should cover areas such as:

- Required columns and exact schema.
- Intended data types.
- Unique and non-null customer identifiers.
- Valid target values.
- Allowed categories.
- Valid numeric ranges.
- Duplicate resolution.
- Missingness after cleaning.
- Infinite or undefined engineered values.
- Feature calculation edge cases.
- Separation of model features from identifiers and metadata.

Include a row-reconciliation table explaining how raw input rows became the final set of unique customer records. Every removed, consolidated, superseded, or rejected record should have an auditable reason.

## 8. Required Report

Submit a professional report describing your investigation, reasoning, and results. The report may be written in Markdown, HTML, PDF, or as a clearly structured notebook export.

The report must include:

### Data understanding

- Summary of the available files and their structures.
- Interpretation of the main fields.
- Identification of the machine-learning problem as binary classification.
- Target distribution and observations about class balance.
- Explanation of the business purpose, intended users, prediction point, and consequences of incorrect predictions.

### Schema design

- The chosen canonical schema.
- Data types and allowed values.
- Source-to-canonical column mappings.
- Columns retained, discarded, or reserved as metadata.
- Reasons for important schema decisions.

### Data-quality findings

- Types of errors and inconsistencies discovered.
- Frequency or scale of each issue.
- Files or fields most affected.
- Problems that could influence model training or evaluation.

### Cleaning decisions

- How each type of issue was handled.
- Why the selected method was appropriate.
- Records or values removed, repaired, replaced, imputed, or left unresolved.
- Alternative approaches considered.
- Limitations and assumptions.

### Feature engineering

- Complete feature list.
- Feature definitions.
- Motivation for each feature or feature family.
- Edge-case handling.
- Leakage considerations.
- Any feature-selection decisions.
- Discussion of whether demographic features should be included, excluded, or separately evaluated, including the reasoning and potential fairness implications.

### Validation and final results

- Row reconciliation.
- Data-quality checks before and after cleaning.
- Final dataset dimensions.
- Remaining missingness or unresolved issues.
- Evidence that the pipeline can be rerun successfully.

## 9. Required Deliverables

Submit:

1. A reproducible data-profiling, standardization, cleaning, and feature-engineering pipeline.
2. A canonical data dictionary or schema definition.
3. A source-to-canonical column-mapping file.
4. The combined standardized dataset before final cleaning.
5. The final cleaned dataset.
6. The feature-engineered model-ready dataset.
7. A rejected-record or unresolved-issue log.
8. A row-reconciliation report.
9. Automated data-quality validation checks.
10. The written report described above.
11. A short `README` explaining how to run the complete pipeline from the untouched raw files.

You may use a Jupyter notebook for exploration and communication, but the final processing logic should be organized so it can run reproducibly from beginning to end. A notebook containing manually executed, order-dependent cells is not sufficient by itself.

## 10. Scope Boundaries

### In scope

- Data discovery and profiling.
- Canonical schema design.
- File standardization and consolidation.
- Data cleaning and quality assessment.
- Duplicate and conflict resolution.
- Feature engineering.
- Data validation and documentation.

### Outside the required scope

- Deploying an application or API.
- Production model serving.
- Building a user interface.
- Collecting additional external data.
- Optimizing a final predictive model, unless separately requested.
- Making automated credit, penalty, or collections decisions about real customers.

You may train a small baseline model as an optional sanity check, but model accuracy is not the primary evaluation criterion for this assignment.

## 11. Evaluation Priorities

Your work will be evaluated primarily on:

- Quality of data investigation.
- Soundness of the canonical schema.
- Correctness and robustness of the pipeline.
- Reasoning behind cleaning decisions.
- Ability to distinguish suspicious values from valid unusual values.
- Quality and relevance of engineered features.
- Prevention of target leakage.
- Reproducibility.
- Validation and row reconciliation.
- Clarity and completeness of documentation.

A high-quality submission should make it possible for another engineer to understand what was found, reproduce every transformation, review every important decision, and safely use the resulting dataset for model development.
