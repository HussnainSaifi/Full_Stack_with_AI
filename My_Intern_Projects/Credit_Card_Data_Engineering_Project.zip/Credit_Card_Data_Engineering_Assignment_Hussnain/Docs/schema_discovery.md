
======================================================================
FILE : accounts_part_04.csv
======================================================================

Rows : 3088
Columns : 27

COLUMN DETAILS

credit_limit_amt | Type=str | Missing=9 | Unique=76
bill_1 | Type=str | Missing=12 | Unique=2695
repay_4 | Type=str | Missing=9 | Unique=13
repay_2 | Type=str | Missing=11 | Unique=11
payment_1 | Type=str | Missing=7 | Unique=1417
record_updated_at | Type=str | Missing=6 | Unique=2
repay_6 | Type=str | Missing=12 | Unique=12
bill_4 | Type=str | Missing=11 | Unique=2570
repay_1 | Type=str | Missing=9 | Unique=15
marital | Type=str | Missing=10 | Unique=13
bill_6 | Type=str | Missing=7 | Unique=2512
payment_5 | Type=str | Missing=12 | Unique=1265
cust_no | Type=str | Missing=2 | Unique=3054
customer_gender | Type=str | Missing=9 | Unique=12
age_in_years | Type=str | Missing=9 | Unique=63
payment_2 | Type=str | Missing=7 | Unique=1455
next_month_default | Type=str | Missing=6 | Unique=3
education_code | Type=str | Missing=13 | Unique=16
repay_3 | Type=str | Missing=8 | Unique=14
bill_2 | Type=str | Missing=9 | Unique=2666
bill_5 | Type=str | Missing=12 | Unique=2547
payment_4 | Type=str | Missing=8 | Unique=1267
export_user | Type=str | Missing=6 | Unique=2
payment_6 | Type=str | Missing=11 | Unique=1271
payment_3 | Type=str | Missing=9 | Unique=1360
repay_5 | Type=str | Missing=11 | Unique=13
bill_3 | Type=str | Missing=10 | Unique=2623

======================================================================
FILE : client_records_q2.csv
======================================================================

Rows : 3188
Columns : 27

COLUMN DETAILS

bill_amount_m1 | Type=str | Missing=6 | Unique=2781
sex_code | Type=str | Missing=11 | Unique=13
payment_amount_m4 | Type=str | Missing=9 | Unique=1314
temporary_flag | Type=str | Missing=6 | Unique=3
customer_age | Type=str | Missing=11 | Unique=63
education_level | Type=str | Missing=10 | Unique=15
payment_amount_m1 | Type=str | Missing=11 | Unique=1467
bill_amount_m5 | Type=str | Missing=9 | Unique=2619
bill_amount_m2 | Type=str | Missing=9 | Unique=2717
bill_amount_m4 | Type=str | Missing=7 | Unique=2666
bill_amount_m3 | Type=str | Missing=9 | Unique=2706
repayment_status_m6 | Type=str | Missing=10 | Unique=12
payment_amount_m2 | Type=str | Missing=12 | Unique=1494
source_system | Type=str | Missing=6 | Unique=2
payment_amount_m5 | Type=str | Missing=8 | Unique=1292
repayment_status_m4 | Type=str | Missing=12 | Unique=13
repayment_status_m2 | Type=str | Missing=14 | Unique=11
credit_limit | Type=str | Missing=9 | Unique=73
default_payment_next_month | Type=str | Missing=6 | Unique=3
repayment_status_m5 | Type=str | Missing=12 | Unique=13
repayment_status_m3 | Type=str | Missing=11 | Unique=13
payment_amount_m3 | Type=str | Missing=9 | Unique=1410
payment_amount_m6 | Type=str | Missing=10 | Unique=1257
batch_id | Type=str | Missing=6 | Unique=2
account_holder_id | Type=str | Missing=2 | Unique=3154
repayment_status_m1 | Type=str | Missing=7 | Unique=14
bill_amount_m6 | Type=str | Missing=12 | Unique=2524

======================================================================
FILE : corrected_accounts.csv
======================================================================

Rows : 2888
Columns : 28

COLUMN DETAILS

payment_amount_m2 | Type=str | Missing=4 | Unique=1383
bill_amount_m5 | Type=str | Missing=7 | Unique=2396
bill_amount_m6 | Type=str | Missing=8 | Unique=2373
credit_limit | Type=str | Missing=9 | Unique=80
source_system | Type=str | Missing=6 | Unique=2
account_holder_id | Type=str | Missing=2 | Unique=2854
bill_amount_m1 | Type=str | Missing=9 | Unique=2529
repayment_status_m4 | Type=str | Missing=9 | Unique=11
education_level | Type=str | Missing=9 | Unique=14
payment_amount_m5 | Type=str | Missing=9 | Unique=1222
bill_amount_m2 | Type=str | Missing=7 | Unique=2499
payment_amount_m6 | Type=str | Missing=9 | Unique=1214
repayment_status_m6 | Type=str | Missing=12 | Unique=11
record_updated_at | Type=str | Missing=6 | Unique=2
sex_code | Type=str | Missing=10 | Unique=13
repayment_status_m5 | Type=str | Missing=12 | Unique=10
payment_amount_m3 | Type=str | Missing=10 | Unique=1309
bill_amount_m3 | Type=str | Missing=7 | Unique=2478
payment_amount_m1 | Type=str | Missing=13 | Unique=1368
default_payment_next_month | Type=str | Missing=6 | Unique=3
bill_amount_m4 | Type=str | Missing=8 | Unique=2416
repayment_status_m1 | Type=str | Missing=8 | Unique=12
free_text_comment | Type=str | Missing=2637 | Unique=2
customer_age | Type=str | Missing=8 | Unique=61
payment_amount_m4 | Type=str | Missing=11 | Unique=1229
repayment_status_m3 | Type=str | Missing=12 | Unique=12
marital_status | Type=str | Missing=10 | Unique=15
repayment_status_m2 | Type=str | Missing=14 | Unique=14

======================================================================
FILE : credit_customers_01.csv
======================================================================

Rows : 3288
Columns : 28

COLUMN DETAILS

row_number | Type=str | Missing=2 | Unique=3254
BILL_AMT1 | Type=str | Missing=10 | Unique=2843
BILL_AMT4 | Type=str | Missing=10 | Unique=2711
PAY_AMT4 | Type=str | Missing=8 | Unique=1356
EDUCATION | Type=str | Missing=10 | Unique=20
PAY_AMT6 | Type=str | Missing=13 | Unique=1343
PAY_2 | Type=str | Missing=13 | Unique=13
BILL_AMT3 | Type=str | Missing=7 | Unique=2767
LIMIT_BAL | Type=str | Missing=14 | Unique=70
BILL_AMT2 | Type=str | Missing=12 | Unique=2792
PAY_5 | Type=str | Missing=9 | Unique=12
source_system | Type=str | Missing=6 | Unique=2
MARRIAGE | Type=str | Missing=13 | Unique=13
PAY_3 | Type=str | Missing=11 | Unique=12
BILL_AMT6 | Type=str | Missing=8 | Unique=2646
AGE | Type=str | Missing=7 | Unique=60
PAY_4 | Type=str | Missing=8 | Unique=11
PAY_AMT3 | Type=str | Missing=10 | Unique=1462
PAY_AMT1 | Type=str | Missing=9 | Unique=1514
PAY_AMT2 | Type=str | Missing=9 | Unique=1553
DEFAULT | Type=str | Missing=6 | Unique=3
ID | Type=str | Missing=2 | Unique=3254
extract_date | Type=str | Missing=6 | Unique=2
PAY_AMT5 | Type=str | Missing=10 | Unique=1354
PAY_6 | Type=str | Missing=9 | Unique=12
PAY_0 | Type=str | Missing=11 | Unique=14
BILL_AMT5 | Type=str | Missing=7 | Unique=2684
SEX | Type=str | Missing=9 | Unique=15

======================================================================
FILE : credit_data_07.csv
======================================================================

Rows : 3288
Columns : 28

COLUMN DETAILS

eduLevel | Type=str | Missing=9 | Unique=18
repaymentStatusM4 | Type=str | Missing=14 | Unique=10
creditLimit | Type=str | Missing=11 | Unique=75
paymentAmountM1 | Type=str | Missing=10 | Unique=1527
billAmountM5 | Type=str | Missing=8 | Unique=2725
marriageStatus | Type=str | Missing=7 | Unique=14
repaymentStatusM6 | Type=str | Missing=8 | Unique=10
paymentAmountM3 | Type=str | Missing=10 | Unique=1434
batch_id | Type=str | Missing=6 | Unique=2
repaymentStatusM3 | Type=str | Missing=12 | Unique=13
billAmountM2 | Type=str | Missing=11 | Unique=2820
billAmountM4 | Type=str | Missing=12 | Unique=2743
billAmountM1 | Type=str | Missing=10 | Unique=2887
paymentAmountM4 | Type=str | Missing=7 | Unique=1340
repaymentStatusM1 | Type=str | Missing=10 | Unique=12
billAmountM6 | Type=str | Missing=9 | Unique=2652
repaymentStatusM5 | Type=str | Missing=11 | Unique=10
row_number | Type=str | Missing=6 | Unique=3251
paymentAmountM6 | Type=str | Missing=11 | Unique=1281
paymentAmountM5 | Type=str | Missing=10 | Unique=1315
billAmountM3 | Type=str | Missing=9 | Unique=2785
customerId | Type=str | Missing=2 | Unique=3254
repaymentStatusM2 | Type=str | Missing=9 | Unique=12
isDefault | Type=str | Missing=6 | Unique=3
paymentAmountM2 | Type=str | Missing=6 | Unique=1502
gender | Type=str | Missing=12 | Unique=11
customerAge | Type=str | Missing=10 | Unique=62
record_updated_at | Type=str | Missing=6 | Unique=2

======================================================================
FILE : customer_batch_feb.csv
======================================================================

Rows : 3188
Columns : 27

COLUMN DETAILS

customerAge | Type=str | Missing=6 | Unique=66
billAmountM1 | Type=str | Missing=11 | Unique=2770
paymentAmountM4 | Type=str | Missing=8 | Unique=1332
paymentAmountM6 | Type=str | Missing=10 | Unique=1247
isDefault | Type=str | Missing=6 | Unique=3
paymentAmountM2 | Type=str | Missing=9 | Unique=1491
billAmountM4 | Type=str | Missing=10 | Unique=2646
batch_id | Type=str | Missing=6 | Unique=2
customerId | Type=str | Missing=2 | Unique=3154
eduLevel | Type=str | Missing=9 | Unique=16
billAmountM6 | Type=str | Missing=8 | Unique=2531
marriageStatus | Type=str | Missing=8 | Unique=13
repaymentStatusM5 | Type=str | Missing=10 | Unique=12
paymentAmountM3 | Type=str | Missing=10 | Unique=1426
paymentAmountM1 | Type=str | Missing=8 | Unique=1496
repaymentStatusM1 | Type=str | Missing=7 | Unique=12
gender | Type=str | Missing=8 | Unique=13
repaymentStatusM2 | Type=str | Missing=16 | Unique=14
record_updated_at | Type=str | Missing=6 | Unique=2
repaymentStatusM3 | Type=str | Missing=7 | Unique=12
repaymentStatusM4 | Type=str | Missing=15 | Unique=11
creditLimit | Type=str | Missing=10 | Unique=76
billAmountM3 | Type=str | Missing=8 | Unique=2699
repaymentStatusM6 | Type=str | Missing=11 | Unique=14
billAmountM5 | Type=str | Missing=7 | Unique=2587
paymentAmountM5 | Type=str | Missing=9 | Unique=1289
billAmountM2 | Type=str | Missing=13 | Unique=2718

======================================================================
FILE : historical_customers.csv
======================================================================

Rows : 2888
Columns : 26

COLUMN DETAILS

status_month_2 | Type=str | Missing=9 | Unique=16
status_month_1 | Type=str | Missing=13 | Unique=12
statement_balance_5 | Type=str | Missing=10 | Unique=2383
statement_balance_2 | Type=str | Missing=10 | Unique=2493
paid_amount_2 | Type=str | Missing=8 | Unique=1317
approved_limit | Type=str | Missing=8 | Unique=73
qualification | Type=str | Missing=9 | Unique=17
paid_amount_1 | Type=str | Missing=9 | Unique=1368
paid_amount_5 | Type=str | Missing=13 | Unique=1153
paid_amount_4 | Type=str | Missing=14 | Unique=1176
legacy_score | Type=str | Missing=6 | Unique=956
statement_balance_3 | Type=str | Missing=8 | Unique=2434
civil_status | Type=str | Missing=8 | Unique=14
paid_amount_3 | Type=str | Missing=11 | Unique=1265
status_month_6 | Type=str | Missing=10 | Unique=13
statement_balance_1 | Type=str | Missing=14 | Unique=2539
CLIENT_ID | Type=str | Missing=2 | Unique=2854
statement_balance_6 | Type=str | Missing=7 | Unique=2314
statement_balance_4 | Type=str | Missing=7 | Unique=2412
target | Type=str | Missing=6 | Unique=3
file_generated_at | Type=str | Missing=6 | Unique=2
Gender_Code | Type=str | Missing=9 | Unique=13
status_month_5 | Type=str | Missing=10 | Unique=10
AgeYears | Type=str | Missing=9 | Unique=56
status_month_4 | Type=str | Missing=10 | Unique=14
status_month_3 | Type=str | Missing=9 | Unique=13

======================================================================
FILE : legacy_export_03.csv
======================================================================

Rows : 2988
Columns : 27

COLUMN DETAILS

statement_balance_1 | Type=str | Missing=2 | Unique=2626
paid_amount_1 | Type=str | Missing=10 | Unique=1440
status_month_6 | Type=str | Missing=8 | Unique=14
paid_amount_3 | Type=str | Missing=7 | Unique=1297
statement_balance_3 | Type=str | Missing=8 | Unique=2533
paid_amount_2 | Type=str | Missing=12 | Unique=1432
status_month_2 | Type=str | Missing=12 | Unique=14
status_month_1 | Type=str | Missing=9 | Unique=16
status_month_5 | Type=str | Missing=10 | Unique=11
free_text_comment | Type=str | Missing=2720 | Unique=2
CLIENT_ID | Type=str | Missing=2 | Unique=2954
target | Type=str | Missing=6 | Unique=3
approved_limit | Type=str | Missing=8 | Unique=81
statement_balance_4 | Type=str | Missing=7 | Unique=2493
statement_balance_6 | Type=str | Missing=13 | Unique=2441
Unnamed: 0 | Type=str | Missing=6 | Unique=2951
civil_status | Type=str | Missing=18 | Unique=14
status_month_3 | Type=str | Missing=8 | Unique=14
statement_balance_5 | Type=str | Missing=9 | Unique=2454
Gender_Code | Type=str | Missing=9 | Unique=13
paid_amount_4 | Type=str | Missing=12 | Unique=1277
status_month_4 | Type=str | Missing=13 | Unique=12
paid_amount_5 | Type=str | Missing=8 | Unique=1266
statement_balance_2 | Type=str | Missing=8 | Unique=2581
paid_amount_6 | Type=str | Missing=10 | Unique=1222
AgeYears | Type=str | Missing=10 | Unique=64
source_system | Type=str | Missing=6 | Unique=2

======================================================================
FILE : regional_export_east.csv
======================================================================

Rows : 2988
Columns : 25

COLUMN DETAILS

payment_6 | Type=str | Missing=7 | Unique=1234
source_system | Type=str | Missing=6 | Unique=2
education_code | Type=str | Missing=9 | Unique=18
bill_1 | Type=str | Missing=8 | Unique=2615
repay_3 | Type=str | Missing=11 | Unique=14
repay_4 | Type=str | Missing=12 | Unique=13
bill_2 | Type=str | Missing=14 | Unique=2566
next_month_default | Type=str | Missing=6 | Unique=3
payment_4 | Type=str | Missing=7 | Unique=1263
repay_6 | Type=str | Missing=13 | Unique=13
export_user | Type=str | Missing=6 | Unique=2
age_in_years | Type=str | Missing=11 | Unique=57
customer_gender | Type=str | Missing=11 | Unique=12
payment_3 | Type=str | Missing=8 | Unique=1316
payment_5 | Type=str | Missing=8 | Unique=1207
marital | Type=str | Missing=9 | Unique=14
payment_2 | Type=str | Missing=9 | Unique=1389
repay_2 | Type=str | Missing=9 | Unique=13
payment_1 | Type=str | Missing=10 | Unique=1419
repay_1 | Type=str | Missing=7 | Unique=16
bill_3 | Type=str | Missing=11 | Unique=2526
credit_limit_amt | Type=str | Missing=6 | Unique=72
cust_no | Type=str | Missing=2 | Unique=2954
bill_4 | Type=str | Missing=8 | Unique=2493
repay_5 | Type=str | Missing=10 | Unique=10

======================================================================
FILE : unknown_batch.csv
======================================================================

Rows : 3088
Columns : 28

COLUMN DETAILS

PAY_AMT1 | Type=str | Missing=5 | Unique=1494
temporary_flag | Type=str | Missing=6 | Unique=3
BILL_AMT1 | Type=str | Missing=8 | Unique=2735
PAY_0 | Type=str | Missing=9 | Unique=13
PAY_6 | Type=str | Missing=10 | Unique=12
PAY_AMT3 | Type=str | Missing=11 | Unique=1360
DEFAULT | Type=str | Missing=6 | Unique=3
PAY_AMT2 | Type=str | Missing=10 | Unique=1446
BILL_AMT4 | Type=str | Missing=11 | Unique=2581
PAY_3 | Type=str | Missing=12 | Unique=10
PAY_AMT5 | Type=str | Missing=9 | Unique=1258
EDUCATION | Type=str | Missing=9 | Unique=17
Unnamed: 0 | Type=str | Missing=6 | Unique=3051
AGE | Type=str | Missing=9 | Unique=61
BILL_AMT3 | Type=str | Missing=14 | Unique=2623
BILL_AMT2 | Type=str | Missing=14 | Unique=2653
MARRIAGE | Type=str | Missing=9 | Unique=13
BILL_AMT5 | Type=str | Missing=12 | Unique=2533
SEX | Type=str | Missing=7 | Unique=13
PAY_AMT4 | Type=str | Missing=11 | Unique=1288
PAY_AMT6 | Type=str | Missing=8 | Unique=1238
file_generated_at | Type=str | Missing=6 | Unique=2
ID | Type=str | Missing=2 | Unique=3054
PAY_2 | Type=str | Missing=7 | Unique=13
BILL_AMT6 | Type=str | Missing=12 | Unique=2470
LIMIT_BAL | Type=str | Missing=7 | Unique=78
PAY_4 | Type=str | Missing=14 | Unique=12
PAY_5 | Type=str | Missing=10 | Unique=12