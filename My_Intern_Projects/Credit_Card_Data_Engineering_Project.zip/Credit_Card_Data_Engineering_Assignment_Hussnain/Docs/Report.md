
# Credit Card Data Engineering Assignment Report

## Objective

The objective of this project was to integrate multiple credit card customer datasets having different schemas into a single standardized dataset suitable for analytics and machine learning.

---

# Dataset Summary

* Total Source Files: 10
* Total Raw Records: 30,880
* Canonical Schema Created: Yes
* Column Mapping Created: Yes

---

# Data Discovery

All source datasets were analyzed to identify:

* Number of rows
* Number of columns
* Missing values
* Data types
* Schema differences

---

# Standardization

Different column names representing the same information were mapped into one canonical schema.

Example:

* ID → customer_id
* CLIENT_ID → customer_id
* customerId → customer_id

---

# Data Cleaning

The following cleaning operations were performed:

* Missing value standardization
* Currency symbol removal
* Numeric conversion
* Age cleaning
* Gender standardization
* Target standardization
* Duplicate detection

---

# Feature Engineering

The following features were created:

* total_bill
* average_bill
* total_payment
* average_payment
* credit_utilization
* payment_ratio
* avg_repayment_status

---

# Validation Summary

* Total Records: 30,880
* Duplicate Records: 0
* Invalid Age Records: 25
* Invalid Credit Limit Records: 12
* Invalid Gender Records: 202
* Invalid Target Records: 80

---

# Final Output

* Standardized Dataset Generated
* Cleaned Dataset Generated
* Model Ready Dataset Generated
* Validation Report Generated
* Rejected Records Generated
* Row Reconciliation Generated

---

# Row Reconciliation

| Stage                 |   Rows |
| --------------------- | -----: |
| Raw Dataset           | 30,880 |
| After Standardization | 30,880 |
| After Cleaning        | 30,880 |
| Rejected Records      |    217 |
| Model Ready Dataset   | 30,663 |

---

# Conclusion

The project successfully transformed ten heterogeneous credit card datasets into a standardized and validated model-ready dataset using a complete data engineering pipeline.
