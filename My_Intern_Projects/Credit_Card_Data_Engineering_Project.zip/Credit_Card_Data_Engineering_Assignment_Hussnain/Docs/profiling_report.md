# Data Discovery & Profiling Report

## accounts_part_04.csv
- Rows : 3088
- Columns : 27

### Column Information

- credit_limit_amt | Type = str | Missing = 9
- bill_1 | Type = str | Missing = 12
- repay_4 | Type = str | Missing = 9
- repay_2 | Type = str | Missing = 11
- payment_1 | Type = str | Missing = 7
- record_updated_at | Type = str | Missing = 6
- repay_6 | Type = str | Missing = 12
- bill_4 | Type = str | Missing = 11
- repay_1 | Type = str | Missing = 9
- marital | Type = str | Missing = 10
- bill_6 | Type = str | Missing = 7
- payment_5 | Type = str | Missing = 12
- cust_no | Type = str | Missing = 2
- customer_gender | Type = str | Missing = 9
- age_in_years | Type = str | Missing = 9
- payment_2 | Type = str | Missing = 7
- next_month_default | Type = str | Missing = 6
- education_code | Type = str | Missing = 13
- repay_3 | Type = str | Missing = 8
- bill_2 | Type = str | Missing = 9
- bill_5 | Type = str | Missing = 12
- payment_4 | Type = str | Missing = 8
- export_user | Type = str | Missing = 6
- payment_6 | Type = str | Missing = 11
- payment_3 | Type = str | Missing = 9
- repay_5 | Type = str | Missing = 11
- bill_3 | Type = str | Missing = 10


## client_records_q2.csv
- Rows : 3188
- Columns : 27

### Column Information

- bill_amount_m1 | Type = str | Missing = 6
- sex_code | Type = str | Missing = 11
- payment_amount_m4 | Type = str | Missing = 9
- temporary_flag | Type = str | Missing = 6
- customer_age | Type = str | Missing = 11
- education_level | Type = str | Missing = 10
- payment_amount_m1 | Type = str | Missing = 11
- bill_amount_m5 | Type = str | Missing = 9
- bill_amount_m2 | Type = str | Missing = 9
- bill_amount_m4 | Type = str | Missing = 7
- bill_amount_m3 | Type = str | Missing = 9
- repayment_status_m6 | Type = str | Missing = 10
- payment_amount_m2 | Type = str | Missing = 12
- source_system | Type = str | Missing = 6
- payment_amount_m5 | Type = str | Missing = 8
- repayment_status_m4 | Type = str | Missing = 12
- repayment_status_m2 | Type = str | Missing = 14
- credit_limit | Type = str | Missing = 9
- default_payment_next_month | Type = str | Missing = 6
- repayment_status_m5 | Type = str | Missing = 12
- repayment_status_m3 | Type = str | Missing = 11
- payment_amount_m3 | Type = str | Missing = 9
- payment_amount_m6 | Type = str | Missing = 10
- batch_id | Type = str | Missing = 6
- account_holder_id | Type = str | Missing = 2
- repayment_status_m1 | Type = str | Missing = 7
- bill_amount_m6 | Type = str | Missing = 12


## corrected_accounts.csv
- Rows : 2888
- Columns : 28

### Column Information

- payment_amount_m2 | Type = str | Missing = 4
- bill_amount_m5 | Type = str | Missing = 7
- bill_amount_m6 | Type = str | Missing = 8
- credit_limit | Type = str | Missing = 9
- source_system | Type = str | Missing = 6
- account_holder_id | Type = str | Missing = 2
- bill_amount_m1 | Type = str | Missing = 9
- repayment_status_m4 | Type = str | Missing = 9
- education_level | Type = str | Missing = 9
- payment_amount_m5 | Type = str | Missing = 9
- bill_amount_m2 | Type = str | Missing = 7
- payment_amount_m6 | Type = str | Missing = 9
- repayment_status_m6 | Type = str | Missing = 12
- record_updated_at | Type = str | Missing = 6
- sex_code | Type = str | Missing = 10
- repayment_status_m5 | Type = str | Missing = 12
- payment_amount_m3 | Type = str | Missing = 10
- bill_amount_m3 | Type = str | Missing = 7
- payment_amount_m1 | Type = str | Missing = 13
- default_payment_next_month | Type = str | Missing = 6
- bill_amount_m4 | Type = str | Missing = 8
- repayment_status_m1 | Type = str | Missing = 8
- free_text_comment | Type = str | Missing = 2637
- customer_age | Type = str | Missing = 8
- payment_amount_m4 | Type = str | Missing = 11
- repayment_status_m3 | Type = str | Missing = 12
- marital_status | Type = str | Missing = 10
- repayment_status_m2 | Type = str | Missing = 14


## credit_customers_01.csv
- Rows : 3288
- Columns : 28

### Column Information

- row_number | Type = str | Missing = 2
- BILL_AMT1 | Type = str | Missing = 10
- BILL_AMT4 | Type = str | Missing = 10
- PAY_AMT4 | Type = str | Missing = 8
- EDUCATION | Type = str | Missing = 10
- PAY_AMT6 | Type = str | Missing = 13
- PAY_2 | Type = str | Missing = 13
- BILL_AMT3 | Type = str | Missing = 7
- LIMIT_BAL | Type = str | Missing = 14
- BILL_AMT2 | Type = str | Missing = 12
- PAY_5 | Type = str | Missing = 9
- source_system | Type = str | Missing = 6
- MARRIAGE | Type = str | Missing = 13
- PAY_3 | Type = str | Missing = 11
- BILL_AMT6 | Type = str | Missing = 8
- AGE | Type = str | Missing = 7
- PAY_4 | Type = str | Missing = 8
- PAY_AMT3 | Type = str | Missing = 10
- PAY_AMT1 | Type = str | Missing = 9
- PAY_AMT2 | Type = str | Missing = 9
- DEFAULT | Type = str | Missing = 6
- ID | Type = str | Missing = 2
- extract_date | Type = str | Missing = 6
- PAY_AMT5 | Type = str | Missing = 10
- PAY_6 | Type = str | Missing = 9
- PAY_0 | Type = str | Missing = 11
- BILL_AMT5 | Type = str | Missing = 7
- SEX | Type = str | Missing = 9


## credit_data_07.csv
- Rows : 3288
- Columns : 28

### Column Information

- eduLevel | Type = str | Missing = 9
- repaymentStatusM4 | Type = str | Missing = 14
- creditLimit | Type = str | Missing = 11
- paymentAmountM1 | Type = str | Missing = 10
- billAmountM5 | Type = str | Missing = 8
- marriageStatus | Type = str | Missing = 7
- repaymentStatusM6 | Type = str | Missing = 8
- paymentAmountM3 | Type = str | Missing = 10
- batch_id | Type = str | Missing = 6
- repaymentStatusM3 | Type = str | Missing = 12
- billAmountM2 | Type = str | Missing = 11
- billAmountM4 | Type = str | Missing = 12
- billAmountM1 | Type = str | Missing = 10
- paymentAmountM4 | Type = str | Missing = 7
- repaymentStatusM1 | Type = str | Missing = 10
- billAmountM6 | Type = str | Missing = 9
- repaymentStatusM5 | Type = str | Missing = 11
- row_number | Type = str | Missing = 6
- paymentAmountM6 | Type = str | Missing = 11
- paymentAmountM5 | Type = str | Missing = 10
- billAmountM3 | Type = str | Missing = 9
- customerId | Type = str | Missing = 2
- repaymentStatusM2 | Type = str | Missing = 9
- isDefault | Type = str | Missing = 6
- paymentAmountM2 | Type = str | Missing = 6
- gender | Type = str | Missing = 12
- customerAge | Type = str | Missing = 10
- record_updated_at | Type = str | Missing = 6


## customer_batch_feb.csv
- Rows : 3188
- Columns : 27

### Column Information

- customerAge | Type = str | Missing = 6
- billAmountM1 | Type = str | Missing = 11
- paymentAmountM4 | Type = str | Missing = 8
- paymentAmountM6 | Type = str | Missing = 10
- isDefault | Type = str | Missing = 6
- paymentAmountM2 | Type = str | Missing = 9
- billAmountM4 | Type = str | Missing = 10
- batch_id | Type = str | Missing = 6
- customerId | Type = str | Missing = 2
- eduLevel | Type = str | Missing = 9
- billAmountM6 | Type = str | Missing = 8
- marriageStatus | Type = str | Missing = 8
- repaymentStatusM5 | Type = str | Missing = 10
- paymentAmountM3 | Type = str | Missing = 10
- paymentAmountM1 | Type = str | Missing = 8
- repaymentStatusM1 | Type = str | Missing = 7
- gender | Type = str | Missing = 8
- repaymentStatusM2 | Type = str | Missing = 16
- record_updated_at | Type = str | Missing = 6
- repaymentStatusM3 | Type = str | Missing = 7
- repaymentStatusM4 | Type = str | Missing = 15
- creditLimit | Type = str | Missing = 10
- billAmountM3 | Type = str | Missing = 8
- repaymentStatusM6 | Type = str | Missing = 11
- billAmountM5 | Type = str | Missing = 7
- paymentAmountM5 | Type = str | Missing = 9
- billAmountM2 | Type = str | Missing = 13


## historical_customers.csv
- Rows : 2888
- Columns : 26

### Column Information

- status_month_2 | Type = str | Missing = 9
- status_month_1 | Type = str | Missing = 13
- statement_balance_5 | Type = str | Missing = 10
- statement_balance_2 | Type = str | Missing = 10
- paid_amount_2 | Type = str | Missing = 8
- approved_limit | Type = str | Missing = 8
- qualification | Type = str | Missing = 9
- paid_amount_1 | Type = str | Missing = 9
- paid_amount_5 | Type = str | Missing = 13
- paid_amount_4 | Type = str | Missing = 14
- legacy_score | Type = str | Missing = 6
- statement_balance_3 | Type = str | Missing = 8
- civil_status | Type = str | Missing = 8
- paid_amount_3 | Type = str | Missing = 11
- status_month_6 | Type = str | Missing = 10
- statement_balance_1 | Type = str | Missing = 14
- CLIENT_ID | Type = str | Missing = 2
- statement_balance_6 | Type = str | Missing = 7
- statement_balance_4 | Type = str | Missing = 7
- target | Type = str | Missing = 6
- file_generated_at | Type = str | Missing = 6
- Gender_Code | Type = str | Missing = 9
- status_month_5 | Type = str | Missing = 10
- AgeYears | Type = str | Missing = 9
- status_month_4 | Type = str | Missing = 10
- status_month_3 | Type = str | Missing = 9


## legacy_export_03.csv
- Rows : 2988
- Columns : 27

### Column Information

- statement_balance_1 | Type = str | Missing = 2
- paid_amount_1 | Type = str | Missing = 10
- status_month_6 | Type = str | Missing = 8
- paid_amount_3 | Type = str | Missing = 7
- statement_balance_3 | Type = str | Missing = 8
- paid_amount_2 | Type = str | Missing = 12
- status_month_2 | Type = str | Missing = 12
- status_month_1 | Type = str | Missing = 9
- status_month_5 | Type = str | Missing = 10
- free_text_comment | Type = str | Missing = 2720
- CLIENT_ID | Type = str | Missing = 2
- target | Type = str | Missing = 6
- approved_limit | Type = str | Missing = 8
- statement_balance_4 | Type = str | Missing = 7
- statement_balance_6 | Type = str | Missing = 13
- Unnamed: 0 | Type = str | Missing = 6
- civil_status | Type = str | Missing = 18
- status_month_3 | Type = str | Missing = 8
- statement_balance_5 | Type = str | Missing = 9
- Gender_Code | Type = str | Missing = 9
- paid_amount_4 | Type = str | Missing = 12
- status_month_4 | Type = str | Missing = 13
- paid_amount_5 | Type = str | Missing = 8
- statement_balance_2 | Type = str | Missing = 8
- paid_amount_6 | Type = str | Missing = 10
- AgeYears | Type = str | Missing = 10
- source_system | Type = str | Missing = 6


## regional_export_east.csv
- Rows : 2988
- Columns : 25

### Column Information

- payment_6 | Type = str | Missing = 7
- source_system | Type = str | Missing = 6
- education_code | Type = str | Missing = 9
- bill_1 | Type = str | Missing = 8
- repay_3 | Type = str | Missing = 11
- repay_4 | Type = str | Missing = 12
- bill_2 | Type = str | Missing = 14
- next_month_default | Type = str | Missing = 6
- payment_4 | Type = str | Missing = 7
- repay_6 | Type = str | Missing = 13
- export_user | Type = str | Missing = 6
- age_in_years | Type = str | Missing = 11
- customer_gender | Type = str | Missing = 11
- payment_3 | Type = str | Missing = 8
- payment_5 | Type = str | Missing = 8
- marital | Type = str | Missing = 9
- payment_2 | Type = str | Missing = 9
- repay_2 | Type = str | Missing = 9
- payment_1 | Type = str | Missing = 10
- repay_1 | Type = str | Missing = 7
- bill_3 | Type = str | Missing = 11
- credit_limit_amt | Type = str | Missing = 6
- cust_no | Type = str | Missing = 2
- bill_4 | Type = str | Missing = 8
- repay_5 | Type = str | Missing = 10


## unknown_batch.csv
- Rows : 3088
- Columns : 28

### Column Information

- PAY_AMT1 | Type = str | Missing = 5
- temporary_flag | Type = str | Missing = 6
- BILL_AMT1 | Type = str | Missing = 8
- PAY_0 | Type = str | Missing = 9
- PAY_6 | Type = str | Missing = 10
- PAY_AMT3 | Type = str | Missing = 11
- DEFAULT | Type = str | Missing = 6
- PAY_AMT2 | Type = str | Missing = 10
- BILL_AMT4 | Type = str | Missing = 11
- PAY_3 | Type = str | Missing = 12
- PAY_AMT5 | Type = str | Missing = 9
- EDUCATION | Type = str | Missing = 9
- Unnamed: 0 | Type = str | Missing = 6
- AGE | Type = str | Missing = 9
- BILL_AMT3 | Type = str | Missing = 14
- BILL_AMT2 | Type = str | Missing = 14
- MARRIAGE | Type = str | Missing = 9
- BILL_AMT5 | Type = str | Missing = 12
- SEX | Type = str | Missing = 7
- PAY_AMT4 | Type = str | Missing = 11
- PAY_AMT6 | Type = str | Missing = 8
- file_generated_at | Type = str | Missing = 6
- ID | Type = str | Missing = 2
- PAY_2 | Type = str | Missing = 7
- BILL_AMT6 | Type = str | Missing = 12
- LIMIT_BAL | Type = str | Missing = 7
- PAY_4 | Type = str | Missing = 14
- PAY_5 | Type = str | Missing = 10

