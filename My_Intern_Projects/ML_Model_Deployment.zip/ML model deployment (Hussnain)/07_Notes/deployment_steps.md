# Task 1: Machine Learning Deployment Lifecycle

## Overview

Model training and model deployment serve two distinct purposes in the machine learning lifecycle:

* **Model Training:** The process of building and optimizing a mathematical model using historical data[cite: 1].
* **Model Deployment:** The process of integrating a trained model into a production environment (such as a Web API) where end-users or applications can send real-time data and receive predictions[cite: 1].

---

## The 10 Steps of ML Deployment Lifecycle

1. **Data Collection**
   Gathering relevant raw data (e.g., customer profiles, billing details, usage history) needed to solve the business problem[cite: 1].
2. **Data Cleaning**
   Handling missing values, removing duplicate records, filtering outliers, and correcting column data types[cite: 1].
3. **Feature Engineering & Selection**
   Transforming raw features into numerical formats (e.g., One-Hot Encoding) and selecting the most relevant inputs for the model[cite: 1].
4. **Model Training**
   Fitting machine learning algorithms (e.g., Random Forest Classifier) on historical training datasets[cite: 1].
5. **Model Evaluation**
   Measuring model performance on test data using metrics such as Accuracy, Precision, Recall, F1-Score, and Confusion Matrix[cite: 1].
6. **Model Saving (Serialization)**
   Exporting the trained model, feature names, and encoders into a persistent binary file (e.g., `churn_model.pkl` using `joblib`) to avoid retraining on every request[cite: 1].
7. **API Development**
   Building a web framework wrapper (e.g., Flask or FastAPI) with dedicated endpoints (e.g., `/predict`) to accept incoming JSON payloads and return predictions[cite: 1].
8. **Model Containerization & Deployment**
   Packaging the API, model file, and dependencies into a Docker container and deploying it to servers or Kubernetes clusters[cite: 1].
9. **Monitoring & Logging**
   Tracking API response latency, error rates, request volumes, and watching for model performance degradation over time[cite: 1].
10. **Model Retraining**
    Periodically updating and retraining the model with fresh incoming data to prevent model drift and maintain prediction accuracy[cite: 1].

## Task 2: Load and Explore Dataset Summary

### Dataset Overview

* **Total Records:** 200 rows
* **Total Columns:** 24 features
* **Target Variable:** `Churn` (Binary: `Yes` / `No`)
* **Missing Values:** 0 missing values across all 24 columns

---

### Target Class Distribution (`Churn`)

* **Retained Customers (`No`):** 118 records (59.0%)
* **Churned Customers (`Yes`):** 82 records (41.0%)

---

### Column Categorization

* **Identifiers & Target:** `CustomerID`, `Churn`, `ChurnReason`
* **Demographics:** `City`, `Gender`, `SeniorCitizen`, `Partner`, `Dependents`
* **Subscriptions & Services:** `TenureMonths`, `PhoneService`, `MultipleLines`, `InternetService`, `OnlineSecurity`, `OnlineBackup`, `DeviceProtection`, `TechSupport`, `StreamingTV`, `StreamingMovies`
* **Billing & Account:** `Contract`, `PaperlessBilling`, `PaymentMethod`, `MonthlyCharges`, `TotalCharges`, `SatisfactionScore`

---

### Key Observations

* **Data Completeness:** All 200 records contain complete data with zero null/missing entries.
* **Class Balance:** The target class shows a 59/41 split between retained and churned customers, providing a well-balanced distribution for model training.
* **Text Formatting:** Case and whitespace normalization on the `Churn` target column yields 118 `No` and 82 `Yes` values.

## Task 3: Data Cleaning

* Removed identifier columns (`CustomerID`) and leak features (`ChurnReason`)[cite: 1].
* Standardized text casing and whitespace in the target column (`Churn`)[cite: 1].
* Exported clean data to `cleaned_telecom_churn.csv`[cite: 1].

## Task 4: Feature Preparation & Encoding

* Applied One-Hot Encoding (`pd.get_dummies(drop_first=True)`) to convert categorical variables to numeric format[cite: 1].
* Encoded binary target labels (`No` -> 0, `Yes` -> 1) using `LabelEncoder`[cite: 1].
* Split dataset into 80% training set and 20% testing set using `train_test_split(random_state=42)`[cite: 1].

## Task 5: Model Training

* Trained a `RandomForestClassifier` with 100 decision trees (`n_estimators=100`, `random_state=42`).

## Task 6: Model Evaluation

* **Accuracy:** Achieved **77.5%** overall prediction accuracy on the unseen test set[cite: 1].
* **Confusion Matrix:** Correctly predicted 20 True Negatives (`No Churn`) and 11 True Positives (`Churn`) out of 40 test samples.
* **Precision & Recall:** Precision for predicting churn was **85%**, while recall reached **61%**.

## Task 7: Model Saving

* Serialized the model along with feature column metadata and label encoders into `churn_model.pkl` using `joblib`[cite: 1].
* Saved copies inside both `03_model/` and `04_api/` directories[cite: 1].

## Task 11 & 12: Docker Containerization

* Created a lightweight `python:3.11-slim` container image.
* Built the image tagged as `churn-api:v1` and exposed container port `5000`[cite: 1].
* Successfully verified predictions on the containerized service endpoint using `curl`[cite: 1].

## Task 13: Deployment Architecture

* **Basic Architecture Flow:** Client → HTTP POST Payload → Flask Web API → Feature Preprocessing (`pd.get_dummies` / reindex) → `churn_model.pkl` → Prediction & Confidence JSON[cite: 1].

## Task 14: Production Deployment Considerations

* **Model Versioning:** Track model artifacts and hyperparameter history using tools like MLflow or DVC[cite: 1].
* **API Security:** Secure API endpoints with JWT/OAuth2 authentication and HTTPS/TLS encryption[cite: 1].
* **Monitoring & Logging:** Use Prometheus and Grafana for monitoring latency/throughput, and maintain structured application logs for auditing[cite: 1].
* **Model Drift:** Periodically assess feature distributions and prediction accuracy to detect data and concept drift[cite: 1].
* **CI/CD:** Automate container builds, testing, and cluster deployment pipelines via GitHub Actions[cite: 1].
