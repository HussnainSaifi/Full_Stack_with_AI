from flask import Flask, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__)

# Load saved model package
model_package = joblib.load("churn_model.pkl")
model = model_package["model"]
feature_columns = model_package["feature_columns"]
label_encoder = model_package["label_encoder"]

@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Telecom Churn Prediction API is running"})

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    
    # Preprocess input request
    input_df = pd.DataFrame([data])
    input_df = pd.get_dummies(input_df)
    input_df = input_df.reindex(columns=feature_columns, fill_value=0)
    
    # Predict
    prediction = model.predict(input_df)[0]
    prediction_label = label_encoder.inverse_transform([prediction])[0]
    probability = model.predict_proba(input_df)[0].max()
    
    return jsonify({
        "prediction": prediction_label,
        "confidence": round(float(probability), 2)
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)